// Triangle.js
export class Triangle {
    constructor(vertices, color) {
        this.vertices = vertices; // Array of six coordinates [x1, y1, x2, y2, x3, y3]
        this.color = color; // Array [r, g, b, a]
    }

    draw(gl, a_Position, u_FragColor) {
        gl.uniform4fv(u_FragColor, this.color);
        drawTriangle(gl, a_Position, this.vertices);
    }
}
