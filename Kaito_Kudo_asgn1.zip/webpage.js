// Vertex and Fragment shader programs
var VSHADER_SOURCE =
  'attribute vec4 a_Position;\n' + 
  'void main() {\n' +
  '  gl_Position = a_Position;\n' +
  '  gl_PointSize = 10.0;\n' +
  '}\n'; 

var FSHADER_SOURCE =
  'void main() {\n' +
  '  gl_FragColor = vec4(1.0, 0.0, 0.0, 1.0);\n' +
  '}\n';

function setupWebGL() {
    // Retrieve <canvas> element
    var canvas = document.getElementById('webgl160');
    // Get the rendering context for WebGL
    var gl = getWebGLContext(canvas);
    if (!gl) {
        console.log('Failed to get the rendering context for WebGL');
        return null;
    }
    return { canvas, gl };
}
var gl, a_Position, u_FragColor;

function main() {
    var setup = setupWebGL();
    if (!setup) {
        console.error('WebGL setup failed: No canvas or WebGL context.');
        return;
    }
    var { canvas, gl } = setup;

    var shaders = connectVariablesToGLSL(gl);
    if (!shaders) {
        console.error('Failed to connect GLSL variables.');
        return;
    }
    var { a_Position, u_FragColor } = shaders;

    // Handle mouse down to start drawing
    canvas.onmousedown = function(event) {
        click(event, gl, canvas, a_Position, u_FragColor, shapes);
    };

    // Handle mouse move to continue drawing if mouse is down
    canvas.onmousemove = function(event) {
        if (event.buttons === 1) {  // Check if the left mouse button is held down
            click(event, gl, canvas, a_Position, u_FragColor, shapes);
        }
    };

    function animate() {
        renderAllShapes(gl, a_Position, u_FragColor, shapes);
        requestAnimationFrame(animate);
    }
    animate(); // Start drawing loop
}

function drawTriangle(gl, a_Position, vertices) {
    // vertices should be an array [x1, y1, x2, y2, x3, y3]
    var vertexBuffer = gl.createBuffer();
    if (!vertexBuffer) {
        console.log('Failed to create the buffer object');
        return -1;
    }

    // Bind the buffer object to target
    gl.bindBuffer(gl.ARRAY_BUFFER, vertexBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vertices), gl.STATIC_DRAW);
    
    gl.vertexAttribPointer(a_Position, 2, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(a_Position);

    // Draw the triangle
    gl.drawArrays(gl.TRIANGLES, 0, 3);
}


function click(event, gl, canvas, a_Position, u_FragColor, shapes) {
    var x = event.clientX;
    var y = event.clientY;
    var rect = event.target.getBoundingClientRect();
    x = ((x - rect.left) - canvas.width / 2) / (canvas.width / 2);
    y = (canvas.height / 2 - (y - rect.top)) / (canvas.height / 2);

    var size = document.getElementById('sizeSlider').value;
    var shapeType = document.getElementById('shapeSelect').value;
    var color = [
        parseFloat(document.getElementById('redSlider').value),
        parseFloat(document.getElementById('greenSlider').value),
        parseFloat(document.getElementById('blueSlider').value),
        1.0
    ];

    // Update shapes array instead of drawing immediately
    shapes.push({x, y, size, type: shapeType, color});
}


function drawShape(gl, a_Position, u_FragColor, x, y, size, shape, color) {
    // Set color and draw based on the shape
    gl.uniform4f(u_FragColor, color[0], color[1], color[2], 1.0);
    switch (shape) {
        case 'point':
            drawPoint(gl, a_Position, x, y, size);
            break;
        case 'circle':
            drawCircle(gl, a_Position, x, y, size);
            break;
        case 'triangle':
            drawTriangle(gl, a_Position, x, y, size);
            break;
    }
}

function clearCanvas(gl) {
    gl.clear(gl.COLOR_BUFFER_BIT);
}


function connectVariablesToGLSL(gl) {
    // Initialize shaders
    if (!initShaders(gl, VSHADER_SOURCE, FSHADER_SOURCE)) {
        console.log('Failed to initialize shaders.');
        return false;
    }

    // Get the storage location of attributes
    var a_Position = gl.getAttribLocation(gl.program, 'a_Position');
    if (a_Position < 0) {
        console.log('Failed to get the storage location of a_Position');
        return false;
    }
    var u_FragColor = gl.getUniformLocation(gl.program, 'u_FragColor');
    if (!u_FragColor) {
        console.log('Failed to get the storage location of u_FragColor');
        return false;
    }

    return { a_Position, u_FragColor };
}

function renderAllShapes(gl, a_Position, u_FragColor, shapes) {
    gl.clear(gl.COLOR_BUFFER_BIT); // Clear <canvas>

    shapes.forEach(shape => {
        const {x, y, size, type, color} = shape;
        gl.uniform4f(u_FragColor, color[0], color[1], color[2], 1.0);
        switch (type) {
            case 'point':
                drawPoint(gl, a_Position, x, y, size);
                break;
            case 'circle':
                drawCircle(gl, a_Position, x, y, size);
                break;
            case 'triangle':
                drawTriangle(gl, a_Position, x, y, size);
                break;
        }
    });
}

function setupWebGL() {
    var canvas = document.getElementById('webgl160');
    var gl = canvas.getContext("webgl", { preserveDrawingBuffer: true }) || canvas.getContext("experimental-webgl", { preserveDrawingBuffer: true });
    if (!gl) {
        console.log('Failed to get the rendering context for WebGL');
        return null;
    }
    return { canvas, gl };
}