var shapes = []; // This will store all your shapes drawn on the canvas
var currentShape = 'point'; // Default shape

document.getElementById('triangleButton').onclick = () => {
    currentShape = 'triangle';
};

document.getElementById('pointButton').onclick = () => {
    currentShape = 'point';
};

function main() {
    var setup = setupWebGL();
    if (!setup) {
        console.error('WebGL setup failed: No canvas or WebGL context.');
        return;
    }
    var { canvas, gl } = setup;

    var shaders = connectVariablesToGLSL(gl);
    if (!shaders) {
        console.error('Failed to connect GLSL variables.');
        return;
    }
    var { a_Position, u_FragColor } = shaders;

    canvas.onmousedown = function(event) {
        click(event, gl, canvas, a_Position, u_FragColor, shapes);
    };

    function animate() {
        renderAllShapes(gl, a_Position, u_FragColor, shapes);
        requestAnimationFrame(animate);
    }
    animate(); // Start the rendering loop
}

function click(event, gl, canvas, a_Position, u_FragColor, shapes) {
    var x = event.clientX;
    var y = event.clientY;
    var rect = event.target.getBoundingClientRect();
    x = ((x - rect.left) - canvas.width / 2) / (canvas.width / 2);
    y = (canvas.height / 2 - (y - rect.top)) / (canvas.height / 2);

    var size = document.getElementById('sizeSlider').value;
    var red = document.getElementById('redSlider').value;
    var green = document.getElementById('greenSlider').value;
    var blue = document.getElementById('blueSlider').value;

    if (currentShape === 'triangle') {
        // Define vertices for a simple static triangle for testing
        let vertices = [x, y, x + 0.1, y, x + 0.05, y + 0.1];
        let triangle = new Triangle(vertices, [red, green, blue, 1.0]);
        shapes.push(triangle);
    } else {
        // Add point logic if needed
    }
    renderAllShapes(gl, a_Position, u_FragColor, shapes);
}
